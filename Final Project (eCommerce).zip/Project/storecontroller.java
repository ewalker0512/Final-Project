package com.store.store;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class storecontroller {
	
	@Autowired
	storeservice tasks;
	
	//Partner Mapping
	
	@CrossOrigin(origins="*")
	@GetMapping("/partnername/{name}")
	public Iterable<partner> findpartnerbyname(@PathVariable String name){
		
		return tasks.findbypartnername(name);
	}
	
	@CrossOrigin(origins="*")
	@GetMapping("/partnerphone_number/{phone_number}")
	public Iterable<partner> findpartnerbyphone_number(@PathVariable int phone_number){
		
		return tasks.findbyphone_number(phone_number);
	}
	
	@CrossOrigin(origins="*")
	@GetMapping("/partneraddress/{address}")
	public Iterable<partner> findbypartneraddress(@PathVariable String address){
		
		return tasks.findbyaddress(address);
	}
	
	@CrossOrigin(origins="*")
	@GetMapping("/partneremail/{email}")
	public Iterable<partner> findbypartneremail(@PathVariable String email){
		
		return tasks.findbyemail(email);
	}
	@CrossOrigin(origins="*")
	@PostMapping("/addpartner")
	public partner addpartner(@RequestParam String name, @RequestParam String address, 
							  @RequestParam String category, @RequestParam int phone_number, @RequestParam String email) {
		
		return tasks.addpartner(name, address, category, phone_number, email);
	}
	
	@CrossOrigin(origins="*")
	@DeleteMapping("/delete/partner")
	public boolean deletebypartnername(@RequestParam("name")String name) {
		
		return tasks.deletepartnerbyname(name);
	}
	
	//Inventory Mapping
	@CrossOrigin(origins="*")
	@GetMapping("/findall")
	public Iterable<inventory> findall(){
		
		return tasks.findbyprice(1);
	}
	@CrossOrigin(origins="*")
	@GetMapping("/inventorybytype/{type}")
	public Iterable<inventory> findbyinventorytype(@PathVariable String type){
		
		return tasks.findbytype(type);
	}
	
	@CrossOrigin(origins="*")
	@PostMapping("/addinventory")
	public inventory addinventory(@RequestParam int partnerid, @RequestParam String name, @RequestParam String type, 
								  @RequestParam int amount, @RequestParam int price) {
		
		return tasks.addinventory(partnerid, name, type, amount, price);
	}
	
	@CrossOrigin(origins="*")
	@PutMapping("/update/inventory/name")
	public Iterable<inventory> updateinventoryname(@RequestParam String name) {
		return tasks.updateByName(name); 
	}
	//Order Mapping
	@CrossOrigin(origins="*")
	@GetMapping("/findorder")
	public Iterable<inventory> findorder(){
		return tasks.inventoryoforder();
	}
	
	@CrossOrigin(origins="*")
	@PostMapping("/addorder")
	public orders addorder(@RequestParam int partnerid, @RequestParam int inventoryid, 
							  @RequestParam int accountingid, @RequestParam String total, 
							  @RequestParam int date, @RequestParam int time) {
		
		return tasks.addorder(partnerid, inventoryid, accountingid, total, date, time);
	}
	
	@CrossOrigin(origins="*")
	@PutMapping("/order/update")
	public orders updateorder(@RequestParam int partnerid, @RequestParam int inventoryid, 
								  @RequestParam int accountingid, @RequestParam String total, 
								  @RequestParam int date, @RequestParam int time) {
			
			return tasks.updateorder(partnerid, inventoryid, accountingid, total, date, time);
	}
	
	@CrossOrigin(origins="*")
	@DeleteMapping("delete/orders")
	public void deletebyorderid(@RequestParam int id) {
		tasks.order.deleteById(id);
		
	}
	//Accounting Mapping
	
	@CrossOrigin(origins="*")
	@GetMapping("/account/{id}")
	public Iterable<accounting> findbyaccountingid (@PathVariable int id) {
		
		return tasks.findbyaccountid(id);
	}
	@CrossOrigin(origins="*")
	@PutMapping("/update/account")
	public boolean updateaccount(@RequestParam int partnerid, @RequestParam int due_date, 
								 @RequestParam boolean payable, @RequestParam boolean receivable, 
								 @RequestParam int amount, Integer id) {
		return tasks.updateaccount(partnerid, due_date, payable, receivable, amount, id); 
	}
	@CrossOrigin(origins="*")
	@DeleteMapping("delete/account")
	public boolean deletebyaccountid(@RequestParam int id) {
		return tasks.deleteaccountbyid(id);
	}
	
}
