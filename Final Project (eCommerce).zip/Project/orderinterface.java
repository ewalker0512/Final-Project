package com.store.store;

import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

@RepositoryRestResource
public interface orderinterface extends CrudRepository<orders, Integer> {
	
	@Query(value = "select * from orders where id = :id", nativeQuery = true)
		Optional<orders> findById(@Param ("id") int id);
	
	@Query(value = "select * from orders where id = :id", nativeQuery = true )
		Optional<orders> updateById(@Param ("id")int id);

	orders deleteBypartnerid(int partnerid);


		
}
