package com.store.store;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class accounting {
	
	
		@Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		private int id;
		
		private int partnerid;
		private int due_date;
		private boolean payable;
		private boolean receivable;
		private int amount;
		
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public int getPartnerid() {
			return partnerid;
		}
		public void setPartnerid(int partnerid) {
			this.partnerid = partnerid;
		}
		public int getDue_date() {
			return due_date;
		}
		public void setDue_date(int due_date) {
			this.due_date = due_date;
		}
		public boolean isPayable() {
			return payable;
		}
		public void setPayable(boolean payable) {
			this.payable = payable;
		}
		public boolean isReceivable() {
			return receivable;
		}
		public void setReceivable(boolean receivable) {
			this.receivable = receivable;
		}
		public int getAmount() {
			return amount;
		}
		public void setAmount(int amount) {
			this.amount = amount;
		}
		
		

}
