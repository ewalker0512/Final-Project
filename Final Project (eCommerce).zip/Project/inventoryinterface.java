package com.store.store;







import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

@RepositoryRestResource
public interface inventoryinterface extends CrudRepository<inventory, Integer> {
	
	@Query(value = "select * from inventory where id = :id", nativeQuery = true)
		Iterable<inventory>findById(@Param("id")int id);
	
	@Query(value = "select * from inventory where type = :type", nativeQuery = true)
		Iterable<inventory>findByType(@Param("type")String type);
		
	@Query(value = "select i.id, o.id as partnerid, i.name, 'order' as [type], i.amount, i.price from inventory i join orders o on o.inventoryid = i.id", nativeQuery = true)
		Iterable<inventory> inventoryoforder();

	@Query(value = "select name from inventory where name = :name", nativeQuery = true)
		Iterable<inventory> updateByName(@Param("name")String name);
}
