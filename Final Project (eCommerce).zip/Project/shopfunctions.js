<script>
    var app = angular.module('shopjob', []);

//Controller 1
    
        app.controller ('shopinventorytype',
                        
                      function($scope, $http){
         $scope.findall = function()    {$http.get("/findall").then(
                                    function(response){
                                        if.(response.data)
                                        $scope.reply = response.data;
                                        console.log("success");
                                        console.log(response);  
                                    },
                                    function(response){
                                    console.log("failure")
                                    console.log(response)
                                    });
                                        };
            $scope.findall();
         
         $scope.bytoys = function()    {$http.get("/inventorybytype/toys").then(
                                  function(response){
                                      if.(response.data)
                                        $scope.reply = response.data;
                                        console.log("success");
                                        console.log(response);
                                  },
                                  function(response){
                                        console.log("failure");
                                        console.log(response);
                                  });
                                       };
         
          $scope.byfood = function()  {$http.get("/inventorybytype/food").then(
                                  function(response){
                                      if.(response.data)
                                        $scope.reply = response.data;
                                        console.log("success");
                                        console.log(response);
                                  },
                                  function(response){
                                        console.log("failure");
                                        console.log(response);
                                  });
                                      };
            
     $scope.byhealth = function() {$http.get("/inventorybytype/health").then(
                                  function(response){
                                      if.(response.data)
                                        $scope.reply = response.data;
                                        console.log("success");
                                        console.log(response);
                                  },
                                  function(response){
                                        console.log("failure");
                                        console.log(response);
                                    });
                                  };
     
     $scope.byaccessories = function() {$http.get("/inventorybytype/accessories").then(
                                  function(response){
                                      if.(response.data)
                                        $scope.reply = response.data;
                                        console.log("success");
                                        console.log(response);
                                  },
                                  function(response){
                                        console.log("failure");
                                        console.log(response);
                                  });
                                       };
        });


//Controller 2
        
        app.controller('shopcontroller2',
                        
                        function($scope, $http){});

//Controller 3
