package com.store.store;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class storeservice {
	
	@Autowired
	partnerinterface partner;
	
	@Autowired
	inventoryinterface inv;
	
	@Autowired
	orderinterface order;
	
	@Autowired
	accountinginterface accounting;
	
//Partner functions
	
		public Iterable<partner> findbypartnername(String name) {
			
			return partner.findAll();
		}
		
		public Iterable<partner> findbyaddress(String address) {
			
			return partner.findAll();
		}
		
		public Iterable<partner> findbycategory(String category) {
			
			return partner.findAll();
		}
		
		public Iterable<partner> findbyphone_number(int phone_number){
			
			return partner.findAll();
		}
		
		public Iterable<partner> findbyemail(String email){
			return partner.findAll();
		}
		public partner addpartner(String name, String address, String category, int phone_number, String email) {
			
			partner newpartner = new partner();
			newpartner.setName(name);
			newpartner.setAddress(address);
			newpartner.setCategory(category);
			newpartner.setPhone_number(phone_number);
			newpartner.setEmail(email);
			return partner.save(newpartner);
		}
		
		
		public boolean deletepartnerbyname(String name) {
			partner.deletepartnerbyname(name);
			return true;
		}
		
//Inventory functions
		
		public Iterable<inventory> findbyinventoryid(int id){
			return inv.findById(id);
		}
		
		public Iterable<inventory> findbyinventoryname(String name){
			return inv.findAll();
		}
		
		public Iterable<inventory> findbytype(String type) {
			return inv.findByType(type);
		}
		
		public Iterable<inventory> findbyprice(int price) {
			return inv.findAll();
		}
		
		public Iterable<inventory> inventoryoforder() {
			
			return inv.inventoryoforder();
		}
		
		public inventory addinventory(int partnerid, String name, String type, int amount, int price) {
			
			inventory newinventory = new inventory();
			newinventory.setPartnerid(partnerid);
			newinventory.setName(name);
			newinventory.setType(type);
			newinventory.setAmount(amount);
			newinventory.setPrice(price);
			
			return inv.save(newinventory);
		}
		

		
		
	
//Order functions	
		
		public Iterable<orders> findbyid(int id) {
			
			return order.findAll();
		}
		
		public orders updateorder(int partnerid, int inventoryid, int accountingid, String total, int date, int time) {
			// TODO Auto-generated method stub
			return null;
		}
		
		public orders addorder(int partnerid, int inventoryid, int accountingid, String total, int date, int time) {
			
			orders neworder = new orders();
			neworder.setPartnerid(partnerid);
			neworder.setInventoryid(inventoryid);
			neworder.setAccountingid(accountingid);
			neworder.setTotal(total);
			neworder.setDate(date);
			neworder.setTime(time);
			
			return order.save(neworder);
		}

//Accounting functions
		
		public Iterable<accounting> findbyaccountid(int id){
			
			return accounting.findAll();
		}
		
		public boolean updateaccount(int partnerid, int due_date, boolean payable, boolean receivable, int amount, Integer id) {
		accounting updateaccount = accounting.findById(id).isPresent()?accounting.findById(id).get():null;
		if(updateaccount == null)
			return false;
		
		updateaccount.setPartnerid(partnerid);
		updateaccount.setDue_date(due_date);
		updateaccount.setPayable(payable);
		updateaccount.setReceivable(receivable);
		updateaccount.setAmount(amount);
		
			accounting.save(updateaccount);
			
			return true;
		}
		
		
		public boolean deleteaccountbyid(int id) {
			
			accounting.deleteaccountbyid(id);
			return true;
		}

		public orders deleteorderbyid(int partnerid) {
			orders neworder = new orders();
			return neworder;
		}

		public Iterable<inventory> updateByName(String name) {
			return null;
		}





}
