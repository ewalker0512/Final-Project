package com.store.store;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

@RepositoryRestResource
public interface partnerinterface extends CrudRepository<partner, Integer> {
	
	@Query(value = "delete from partner where name = :name", nativeQuery = true)
		void deletepartnerbyname(@Param("name")String name);
	

}
