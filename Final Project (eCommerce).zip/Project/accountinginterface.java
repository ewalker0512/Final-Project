package com.store.store;

import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

@RepositoryRestResource
public interface accountinginterface extends CrudRepository<accounting, Integer> {
	
	@Query(value = "delete * from accounting where id = :id", nativeQuery = true)
		void deleteaccountbyid(@Param ("id") int id);
		
	@Query(value = "select * from accounting where id = :id", nativeQuery = true)
	Optional<accounting>updateById(@Param("id")int id);

}
